# Leiningen plugin

This plugin adds completions for the [Leiningen](https://leiningen.org/) Clojure build tool.

To use it, add `lein` to the plugins array in your zshrc file:

```zsh
plugins=(... lein)
```
